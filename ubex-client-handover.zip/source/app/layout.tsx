import type { Metadata } from 'next';
import './site.css';
import './logo.css';

export const metadata: Metadata = {
  title:'UBEX — Your Voice. Their Trust.',
  description:'UBEX calling services for growing businesses.',
  icons:{icon:'/ubex-logo.jpg',shortcut:'/ubex-logo.jpg'},
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
