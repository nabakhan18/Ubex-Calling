import { getPublishedContent } from '@/lib/content';
import { renderSite } from '@/lib/render-site';
import SiteMotion from './site-motion';

export const dynamic = 'force-dynamic';
export default async function Home() {
  const content=await getPublishedContent();
  return <><div dangerouslySetInnerHTML={{__html:renderSite(content)}}/><SiteMotion/></>;
}
