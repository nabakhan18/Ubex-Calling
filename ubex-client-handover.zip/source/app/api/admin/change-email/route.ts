import { changeEmail,isAdmin } from '@/lib/admin-auth';

export const runtime='nodejs';
export async function POST(request:Request){
  const origin=request.headers.get('origin');
  if(!origin||new URL(origin).origin!==new URL(request.url).origin||!(await isAdmin()))
    return Response.json({error:'Unauthorized'},{status:401});
  try{
    const body=await request.json() as {currentPassword?:unknown;newEmail?:unknown};
    if(typeof body.currentPassword!=='string'||body.currentPassword.length>256||typeof body.newEmail!=='string'||body.newEmail.length>254)
      return Response.json({error:'Invalid email or password'},{status:400});
    const newEmail=body.newEmail.trim().toLowerCase();
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail))
      return Response.json({error:'Enter a valid email address.'},{status:400});
    const updated=await changeEmail(body.currentPassword,newEmail);
    if(!updated) return Response.json({error:'Current password is incorrect.'},{status:401});
    return Response.json({ok:true,email:updated});
  }catch(e){
    if(e instanceof Error&&e.message==='Enter a different valid email address.')
      return Response.json({error:e.message},{status:400});
    return Response.json({error:'Email could not be changed. Please try again.'},{status:503});
  }
}
