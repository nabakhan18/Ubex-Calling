import { isAdmin } from '@/lib/admin-auth';
import { contentSchema,defaults,getContentRow,saveDraft } from '@/lib/content';

export const dynamic='force-dynamic';
function sameOrigin(request:Request){const origin=request.headers.get('origin');return !!origin&&new URL(origin).origin===new URL(request.url).origin;}
export async function GET(){
  if(!(await isAdmin())) return Response.json({error:'Unauthorized'},{status:401});
  try{const row=await getContentRow();return Response.json({content:row?.draft??defaults,published:row?.published??defaults,revision:row?.revision??0,publishedAt:row?.publishedAt??null},{headers:{'Cache-Control':'no-store'}});}
  catch{return Response.json({error:'Website storage is unavailable'},{status:503});}
}
export async function PUT(request:Request){
  if(!(await isAdmin())) return Response.json({error:'Unauthorized'},{status:401});
  if(!sameOrigin(request)) return Response.json({error:'Invalid origin'},{status:403});
  try{
    const body=await request.json() as {content:unknown;revision:unknown};
    const content=contentSchema.parse(body.content);
    if(typeof body.revision!=='number'||!Number.isSafeInteger(body.revision)||body.revision<0) return Response.json({error:'Invalid revision'},{status:400});
    const next=await saveDraft(content,body.revision);
    if(next===null) return Response.json({error:'This draft changed in another session. Reload before saving.'},{status:409});
    return Response.json({revision:next});
  }catch(error){return Response.json({error:error instanceof Error?error.message:'Could not save draft'},{status:503});}
}
