import { isAdmin } from '@/lib/admin-auth';
import { publishDraft } from '@/lib/content';

export async function POST(request:Request){
  if(!(await isAdmin())) return Response.json({error:'Unauthorized'},{status:401});
  const origin=request.headers.get('origin');
  if(!origin||new URL(origin).origin!==new URL(request.url).origin) return Response.json({error:'Invalid origin'},{status:403});
  try{
    const {revision}=await request.json() as {revision:unknown};
    if(typeof revision!=='number'||!Number.isSafeInteger(revision)||revision<1) return Response.json({error:'Save the draft first'},{status:400});
    const next=await publishDraft(revision);
    if(next===null) return Response.json({error:'The draft changed. Reload before publishing.'},{status:409});
    return Response.json({revision:next,publishedAt:Date.now()});
  }catch{return Response.json({error:'Website storage is unavailable'},{status:503});}
}
