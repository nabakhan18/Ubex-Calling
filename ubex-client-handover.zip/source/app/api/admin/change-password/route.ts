import { changePassword,isAdmin } from '@/lib/admin-auth';

export const runtime='nodejs';
export async function POST(request:Request){
  const origin=request.headers.get('origin');
  if(!origin||new URL(origin).origin!==new URL(request.url).origin||!(await isAdmin()))
    return Response.json({error:'Unauthorized'},{status:401});
  try{
    const body=await request.json() as {currentPassword?:unknown;newPassword?:unknown};
    if(typeof body.currentPassword!=='string'||typeof body.newPassword!=='string'||body.currentPassword.length>256)
      return Response.json({error:'Invalid password'},{status:400});
    if(body.newPassword.length<12||body.newPassword.length>128||body.newPassword===body.currentPassword)
      return Response.json({error:'Use a different password with at least 12 characters.'},{status:400});
    if(!(await changePassword(body.currentPassword,body.newPassword)))
      return Response.json({error:'Current password is incorrect.'},{status:401});
    return Response.json({ok:true});
  }catch{
    return Response.json({error:'Password could not be changed. Please try again.'},{status:503});
  }
}
