import { startSession,verifyLogin } from '@/lib/admin-auth';

export const runtime='nodejs';
export async function POST(request:Request){
  const origin=request.headers.get('origin');
  if(!origin||new URL(origin).origin!==new URL(request.url).origin) return Response.json({error:'Invalid origin'},{status:403});
  try{
    const body=await request.json() as {email?:unknown;password?:unknown};
    if(typeof body.email!=='string'||typeof body.password!=='string'||body.email.length>254||body.password.length>256)
      return Response.json({error:'Incorrect email or password'},{status:401});
    if(!(await verifyLogin(body.email,body.password)))
      return Response.json({error:'Incorrect email or password'},{status:401});
    await startSession();return Response.json({ok:true});
  }catch{return Response.json({error:'Admin login is unavailable'},{status:503});}
}
