import { endSession,isAdmin } from '@/lib/admin-auth';

export async function POST(request:Request){
  const origin=request.headers.get('origin');
  if(!origin||new URL(origin).origin!==new URL(request.url).origin||!(await isAdmin())) return Response.json({error:'Unauthorized'},{status:401});
  await endSession();return Response.redirect(new URL('/admin/login',request.url),303);
}
