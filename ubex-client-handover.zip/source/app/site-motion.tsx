'use client';
import { useEffect } from 'react';

export default function SiteMotion() {
  useEffect(() => {
    const root = document.documentElement;
    const hero = document.getElementById('heroScroll');
    const header = document.getElementById('siteHeader');
    const btn = document.getElementById('menuBtn');
    const nav = document.getElementById('navLinks');
    if (!hero || !header || !btn || !nav) return;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    let ticking = false;
    let frame = 0;
    function update() {
      if (ticking) return;
      ticking = true;
      frame = requestAnimationFrame(() => {
        const y = scrollY;
        const max = Math.max(1, document.documentElement.scrollHeight - innerHeight);
        const percent = Math.min(100, Math.max(0, y/max*100));
        root.style.setProperty('--progress', `${percent}%`);
        root.style.setProperty('--phone-angle', `${-18+percent*.62}deg`);
        const rect = hero!.getBoundingClientRect();
        const range = Math.max(1, hero!.offsetHeight-innerHeight);
        const p = Math.min(1, Math.max(0, -rect.top/range));
        const pose = reduced ? 0 : Math.min(1,Math.max(0,(p-.24)/.23));
        for (const [key,val] of Object.entries({
          '--hero-progress':p.toFixed(3),'--pose':pose.toFixed(3),'--pose-a':(1-pose).toFixed(3),
          '--halo-scale':(1+p*.12).toFixed(3),'--scene-scale':(1+p*.11).toFixed(3),
          '--scene-y':`${(-p*39).toFixed(1)}px`,'--route-scale':(.9+p*.15).toFixed(3),
          '--bubble-one-y':`${(-p*25).toFixed(1)}px`,'--bubble-two-opacity':Math.min(1,p*2).toFixed(3),
          '--bubble-two-y':`${(30-p*55).toFixed(1)}px`,'--bubble-three-opacity':Math.min(1,Math.max(0,(p-.42)*2.5)).toFixed(3),
          '--bubble-three-y':`${(35-p*40).toFixed(1)}px`,
        })) root.style.setProperty(key,val);
        header!.classList.toggle('scrolled',y>30);
        ticking = false;
      });
    }
    addEventListener('scroll',update,{passive:true});
    addEventListener('resize',update);
    update();
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if(entry.isIntersecting) entry.target.classList.add('in-view');
      else if(!reduced) entry.target.classList.remove('in-view');
    }),{threshold:.08,rootMargin:'0px 0px -20px 0px'});
    document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
    const toggle = () => { const open=nav!.classList.toggle('open'); btn!.setAttribute('aria-expanded',String(open)); btn!.setAttribute('aria-label',open?'Close navigation':'Open navigation'); };
    const close = () => { nav!.classList.remove('open'); btn!.setAttribute('aria-expanded','false'); btn!.setAttribute('aria-label','Open navigation'); };
    btn.addEventListener('click',toggle);
    nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',close));
    const year = document.getElementById('year');
    if(year) year.textContent=String(new Date().getFullYear());
    return () => { removeEventListener('scroll',update); removeEventListener('resize',update); cancelAnimationFrame(frame); observer.disconnect(); btn.removeEventListener('click',toggle); nav.querySelectorAll('a').forEach(a=>a.removeEventListener('click',close)); };
  },[]);
  return null;
}
