'use client';
import { useState } from 'react';

export default function PasswordSettings({email,onEmailChange}:{email:string;onEmailChange:(email:string)=>void}){
  const [newEmail,setNewEmail]=useState('');
  const [emailPassword,setEmailPassword]=useState('');
  const [emailBusy,setEmailBusy]=useState(false);
  const [emailMessage,setEmailMessage]=useState('');
  const [emailError,setEmailError]=useState(false);
  const [currentPassword,setCurrentPassword]=useState('');
  const [newPassword,setNewPassword]=useState('');
  const [confirmPassword,setConfirmPassword]=useState('');
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState('');
  const [error,setError]=useState(false);
  async function submitEmail(event:React.FormEvent){
    event.preventDefault();setEmailMessage('');
    if(newEmail.trim().toLowerCase()===email){setEmailError(true);setEmailMessage('Enter a different email address.');return;}
    setEmailBusy(true);
    try{
      const response=await fetch('/api/admin/change-email',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({currentPassword:emailPassword,newEmail})});
      const data=await response.json() as {email?:string;error?:string};
      if(!response.ok||!data.email) throw new Error(data.error??'Could not change email');
      onEmailChange(data.email);setNewEmail('');setEmailPassword('');setEmailError(false);
      setEmailMessage('Login email updated. Other admin sessions have been signed out.');
    }catch(e){setEmailError(true);setEmailMessage(e instanceof Error?e.message:'Could not change email');}
    finally{setEmailBusy(false);}
  }
  async function submit(event:React.FormEvent){
    event.preventDefault();setMessage('');
    if(newPassword!==confirmPassword){setError(true);setMessage('New passwords do not match.');return;}
    if(newPassword.length<12||newPassword===currentPassword){setError(true);setMessage('Use a different password with at least 12 characters.');return;}
    setBusy(true);
    try{
      const response=await fetch('/api/admin/change-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({currentPassword,newPassword})});
      const data=await response.json() as {error?:string};
      if(!response.ok) throw new Error(data.error??'Could not change password');
      setCurrentPassword('');setNewPassword('');setConfirmPassword('');setError(false);
      setMessage('Password updated. Other admin sessions have been signed out.');
    }catch(e){setError(true);setMessage(e instanceof Error?e.message:'Could not change password');}
    finally{setBusy(false);}
  }
  return <div className="admin-security">
    <section className="admin-security-section"><div className="admin-security-intro"><span className="admin-kicker">ADMINISTRATOR ACCOUNT</span><h3>Change login email</h3><p>Current login email: <strong>{email}</strong>. Confirm your password to switch to a new address. Other signed-in sessions will end.</p></div><form className="admin-form admin-security-form" onSubmit={submitEmail}><label><span>New email address</span><input type="email" autoComplete="email" maxLength={254} value={newEmail} onChange={e=>setNewEmail(e.target.value)} required/></label><label><span>Current password</span><input type="password" autoComplete="current-password" value={emailPassword} onChange={e=>setEmailPassword(e.target.value)} required/></label><button className="admin-change-password" type="submit" disabled={emailBusy}>{emailBusy?'Updating…':'Update email ↗'}</button>{emailMessage&&<p role={emailError?'alert':'status'} className={`admin-message ${emailError?'admin-error':''}`}>{emailMessage}</p>}</form></section>
    <section className="admin-security-section"><div className="admin-security-intro"><span className="admin-kicker">ACCOUNT SECURITY</span><h3>Change password</h3><p>Enter your current password to set a new one. Other signed-in sessions will end.</p></div><form className="admin-form admin-security-form" onSubmit={submit}><label><span>Current password</span><input type="password" autoComplete="current-password" value={currentPassword} onChange={e=>setCurrentPassword(e.target.value)} required/></label><label><span>New password</span><input type="password" autoComplete="new-password" minLength={12} maxLength={128} value={newPassword} onChange={e=>setNewPassword(e.target.value)} required/><small>At least 12 characters.</small></label><label><span>Confirm new password</span><input type="password" autoComplete="new-password" minLength={12} maxLength={128} value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} required/></label><button className="admin-change-password" type="submit" disabled={busy}>{busy?'Updating…':'Update password ↗'}</button>{message&&<p role={error?'alert':'status'} className={`admin-message ${error?'admin-error':''}`}>{message}</p>}</form></section>
  </div>;
}
