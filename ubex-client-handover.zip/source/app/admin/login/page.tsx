'use client';
import { useState } from 'react';
import '../admin.css';
import '../login.css';

export default function Login(){
  const [email,setEmail]=useState('');const [password,setPassword]=useState('');const [error,setError]=useState('');const [busy,setBusy]=useState(false);
  async function submit(event:React.FormEvent){
    event.preventDefault();setBusy(true);setError('');
    try{
      const response=await fetch('/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});
      if(!response.ok){const data=await response.json() as {error?:string};throw new Error(data.error??'Could not sign in');}
      window.location.assign('/admin');
    }catch(e){setError(e instanceof Error?e.message:'Could not sign in');setBusy(false);}
  }
  return <main className="admin-login-page"><form onSubmit={submit} className="admin-login-card"><a href="/"><img src="/ubex-logo.jpg" alt="UBEX" width="98" height="98"/></a><span className="admin-kicker">UBEX CONTENT STUDIO</span><h1>Admin sign in</h1><p>Enter your admin email and password to edit your website.</p><label htmlFor="admin-email">Email address</label><input id="admin-email" type="email" autoComplete="username" value={email} onChange={e=>setEmail(e.target.value)} required/><label htmlFor="admin-password">Password</label><input id="admin-password" type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} required/><button type="submit" disabled={busy}>{busy?'Signing in…':'Sign in ↗'}</button>{error&&<p role="alert" className="admin-login-error">{error}</p>}</form></main>;
}
