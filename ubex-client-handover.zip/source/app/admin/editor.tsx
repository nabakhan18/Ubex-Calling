'use client';
import { useState } from 'react';
import type { SiteContent } from '@/lib/content';
import PasswordSettings from './password-settings';
import './admin.css';
import './logo-admin.css';

type Props = { initial:SiteContent; published:SiteContent; revision:number; email:string; publishedAt:number|null };
type Section = 'Home'|'Services'|'Industries'|'Process'|'About'|'Contact'|'Security';
const sections:Section[] = ['Home','Services','Industries','Process','About','Contact','Security'];
const fields:Record<Section,[keyof SiteContent,string,boolean][]> = {
  Home:[['heroEyebrow','Intro line',false],['heroTitle','Headline, first line',false],['heroAccent','Headline, blue line',false],['heroDescription','Description',true]],
  Services:[['servicesTitle','Headline, first line',false],['servicesTitleSecond','Headline, second line',false],['servicesLead','Introduction',true]],
  Industries:[['industriesTitle','Headline, first line',false],['industriesTitleSecond','Headline, second line',false],['industriesLead','Introduction',true]],
  Process:[['processTitle','Headline, first line',false],['processTitleSecond','Headline, second line',false],['processLead','Introduction',true]],
  About:[['aboutTitle','Headline, first line',false],['aboutTitleSecond','Headline, second line',false],['aboutLead','Description',true],['aboutPoint1','Highlight 1',false],['aboutPoint2','Highlight 2',false],['aboutPoint3','Highlight 3',false]],
  Contact:[['contactTitle','Headline, first line',false],['contactTitleSecond','Headline, second line',false],['contactLead','Description',true],['contactEmail','Contact email',false]],
  Security:[],
};
const groups:Partial<Record<Section,{key:'services'|'industries'|'steps';label:string}>> = {
  Services:{key:'services',label:'Service'}, Industries:{key:'industries',label:'Industry'}, Process:{key:'steps',label:'Step'},
};

export default function AdminEditor({initial,published,revision:initialRevision,email,publishedAt:initialPublishedAt}:Props) {
  const [content,setContent] = useState<SiteContent>(initial);
  const [live,setLive] = useState<SiteContent>(published);
  const [revision,setRevision] = useState(initialRevision);
  const [publishedAt,setPublishedAt] = useState(initialPublishedAt);
  const [tab,setTab] = useState<Section>('Home');
  const [accountEmail,setAccountEmail] = useState(email);
  const [busy,setBusy] = useState<'save'|'publish'|null>(null);
  const [message,setMessage] = useState('');
  const [error,setError] = useState(false);
  const dirty = JSON.stringify(content)!==JSON.stringify(live);
  const [edited,setEdited] = useState(false);
  const setField = (key:keyof SiteContent,value:string) => { setContent(prev=>({...prev,[key]:value}));setEdited(true);setMessage(''); };
  const setPair = (key:'services'|'industries'|'steps',index:number,part:number,value:string) => {
    setContent(prev=>({...prev,[key]:prev[key].map((pair,i)=>i===index ? pair.map((text,j)=>j===part?value:text) as [string,string] : pair)}));
    setEdited(true);setMessage('');
  };
  async function save() {
    setBusy('save');setMessage('');
    try {
      const response=await fetch('/api/admin/content',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({content,revision})});
      const data=await response.json() as {error?:string;revision?:number};
      if(!response.ok) throw new Error(data.error || 'Could not save draft');
      setRevision(data.revision!);setEdited(false);setError(false);setMessage('Draft saved. Publish when you are ready.');
    } catch(e) {setError(true);setMessage(e instanceof Error?e.message:'Could not save draft');}
    finally {setBusy(null);}
  }
  async function publish() {
    if(edited) {setError(true);setMessage('Save your latest edits before publishing.');return;}
    setBusy('publish');setMessage('');
    try {
      const response=await fetch('/api/admin/publish',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision})});
      const data=await response.json() as {error?:string;revision?:number;publishedAt?:number};
      if(!response.ok) throw new Error(data.error || 'Could not publish');
      setRevision(data.revision!);setLive(content);setPublishedAt(data.publishedAt!);setError(false);setMessage('Published. The live website now shows these changes.');
    } catch(e) {setError(true);setMessage(e instanceof Error?e.message:'Could not publish');}
    finally {setBusy(null);}
  }
  const group=groups[tab];
  return <main className="admin-shell">
    <aside className="admin-sidebar"><a href="/" className="admin-logo"><img src="/ubex-logo.jpg" alt="UBEX"/><small>STUDIO</small></a><div className="admin-label">CONTENT</div><nav aria-label="Editor sections">{sections.map((item,i)=><button type="button" className={tab===item?'active':''} key={item} onClick={()=>{setTab(item);setMessage('')}}><span>{String(i+1).padStart(2,'0')}</span>{item}<b>↗</b></button>)}</nav><div className="admin-sidebar-bottom"><div className="admin-avatar">{accountEmail[0]?.toUpperCase()}</div><div><strong>Administrator</strong><small>{accountEmail}</small></div></div></aside>
    <div className="admin-main"><header className="admin-top"><div><span className="admin-kicker">UBEX / CONTENT STUDIO</span><h1>Website editor<span>.</span></h1><p>Shape the message your customers see.</p></div><a className="admin-view" href="/" target="_blank" rel="noopener noreferrer">View live website ↗</a></header>
      <div className="admin-status"><span className="status-dot"/> <strong>Live website</strong><span className="status-separator">/</span><span>{publishedAt?`Last published ${new Date(publishedAt).toLocaleDateString()}`:'Original design is live'}</span><span className="status-pill">{edited?'Unsaved changes':dirty?'Draft ready':'Up to date'}</span></div>
      <div className="admin-workspace"><div className="admin-workspace-title"><div><span className="admin-kicker">{tab==='Security'?'ACCOUNT SETTINGS':`SECTION ${String(sections.indexOf(tab)+1).padStart(2,'0')} / 06`}</span><h2>{tab}</h2></div><p>{tab==='Security'?'Update your administrator email and password.':'Edit the copy below. Save a draft, then publish it to the site.'}</p></div>
      {tab==='Security'?<PasswordSettings email={accountEmail} onEmailChange={setAccountEmail}/>:<div className="admin-form">{fields[tab].map(([key,label,multi])=><label key={key}><span>{label}</span>{multi?<textarea value={content[key] as string} onChange={e=>setField(key,e.target.value)} rows={3} maxLength={650}/>:<input value={content[key] as string} onChange={e=>setField(key,e.target.value)} maxLength={key==='contactEmail'?254:160}/>}</label>)}
      {group && <div className="admin-items"><h3>{tab} cards</h3><p>Cards keep their icons and layout. You can edit every title and description.</p>{content[group.key].map((pair,index)=><div className="admin-item" key={index}><div className="admin-item-num">{String(index+1).padStart(2,'0')}</div><div><label><span>{group.label} title</span><input value={pair[0]} onChange={e=>setPair(group.key,index,0,e.target.value)} maxLength={160}/></label><label><span>Description</span><textarea value={pair[1]} onChange={e=>setPair(group.key,index,1,e.target.value)} rows={2} maxLength={650}/></label></div></div>)}</div>}
      </div>}</div>{tab!=='Security'&&<div className="admin-actions"><div><strong>{edited?'Your latest edits are not saved':dirty?'Draft differs from the live site':'Everything is published'}</strong><small>Changes appear on the website after Publish.</small></div><div className="admin-buttons"><button className="admin-save" type="button" onClick={save} disabled={!!busy||!edited}>{busy==='save'?'Saving…':'Save draft'}</button><button className="admin-publish" type="button" onClick={publish} disabled={!!busy||!dirty||edited||revision===0}>{busy==='publish'?'Publishing…':'Publish changes ↗'}</button></div></div>}{message&&tab!=='Security'&&<div role="status" className={`admin-message ${error?'admin-error':''}`}>{message}</div>}</div>
  </main>;
}
