import { redirect } from 'next/navigation';
import { adminEmail,isAdmin } from '@/lib/admin-auth';
import { getContentRow,defaults } from '@/lib/content';
import AdminEditor from './editor';

export const dynamic='force-dynamic';
export default async function AdminPage(){
  if(!(await isAdmin())) redirect('/admin/login');
  const row=await getContentRow();
  return <AdminEditor initial={row?.draft??defaults} published={row?.published??defaults} revision={row?.revision??0} publishedAt={row?.publishedAt??null} email={await adminEmail()}/>;
}
