# UBEX Calling Services

Next.js website with a private admin editor. The production project is `ubex-calling-services-live`.

## Environment

- `ADMIN_PASSWORD_HASH`: initial `salt:hex` password verifier generated with Node.js `scryptSync(password, salt, 32)`.
- `ADMIN_SESSION_SECRET`: random secret of at least 32 characters for signed admin cookies.
- `BLOB_READ_WRITE_TOKEN`: token for the project's private Vercel Blob store. The content editor and password settings need this store.
- `ADMIN_EMAIL` (optional): initial administrator login email. Defaults to `ubex.service@gmail.com` if unset.

The admin login is at `/admin/login`. The administrator must enter the email and password. After login, the **Security** section lets the administrator change either the login email or password by entering the current password. Both are stored in the private Blob store, and earlier sessions are invalidated. The initial environment hash is used only until the first password change. Changing `ADMIN_PASSWORD_HASH` later does not reset the password while the private `ubex/admin-auth.json` record exists.

To change the admin email, use the dashboard's **Security → Change login email** form. Once changed there, the private Blob record takes precedence over `ADMIN_EMAIL`; editing the environment variable will not override it. Share credentials privately. Do not commit passwords, tokens, `.env` files, or the initial setup file.

## Development

Run `npm install`, then `npm run dev`. Check with `npm run typecheck` and `npm run build`. Connect a private Vercel Blob store and set the required environment variables for login and content editing.
