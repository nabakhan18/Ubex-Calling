import { randomBytes, scryptSync } from 'node:crypto';

if (!process.stdin.isTTY) {
  console.error('Run this script in an interactive terminal on your own computer.');
  process.exit(1);
}

process.stdout.write('Choose a new admin password (at least 12 characters): ');
process.stdin.setRawMode(true);
process.stdin.resume();
let password = '';
process.stdin.on('data', chunk => {
  for (const character of chunk.toString('utf8')) {
    if (character === '\u0003') {
      process.stdin.setRawMode(false);
      process.stdout.write('\n');
      process.exit(130);
    }
    if (character === '\r' || character === '\n') {
      process.stdin.setRawMode(false);
      process.stdin.pause();
      process.stdout.write('\n');
      if (password.length < 12 || password.length > 128) {
        console.error('Password must be between 12 and 128 characters. Run the script again.');
        process.exitCode = 1;
        return;
      }
      const salt = randomBytes(16).toString('hex');
      console.log(`ADMIN_PASSWORD_HASH=${salt}:${scryptSync(password, salt, 32).toString('hex')}`);
      console.log(`ADMIN_SESSION_SECRET=${randomBytes(32).toString('hex')}`);
      password = '';
      return;
    }
    if (character === '\u007f' || character === '\b') {
      if (password.length) {
        password = password.slice(0, -1);
        process.stdout.write('\b \b');
      }
    } else if (character >= ' ' && character !== '\u007f') {
      password += character;
      process.stdout.write('*');
    }
  }
});
