import { z } from 'zod';
import { get, put } from '@vercel/blob';
import { defaultContent } from './site-defaults';

const line=z.string().trim().min(1).max(160);
const paragraph=z.string().trim().min(1).max(650);
const pair=z.tuple([line,paragraph]);
export const contentSchema=z.object({
  heroEyebrow:line,heroTitle:line,heroAccent:line,heroDescription:paragraph,
  servicesTitle:line,servicesTitleSecond:line,servicesLead:paragraph,
  industriesTitle:line,industriesTitleSecond:line,industriesLead:paragraph,
  processTitle:line,processTitleSecond:line,processLead:paragraph,
  aboutTitle:line,aboutTitleSecond:line,aboutLead:paragraph,
  aboutPoint1:line,aboutPoint2:line,aboutPoint3:line,
  contactTitle:line,contactTitleSecond:line,contactLead:paragraph,
  contactEmail:z.string().trim().email().max(254),
  services:z.array(pair).length(6),industries:z.array(pair).length(6),steps:z.array(pair).length(5),
}).strict();
export type SiteContent=z.infer<typeof contentSchema>;
export const defaults:SiteContent=contentSchema.parse(defaultContent);
export type ContentRow={draft:SiteContent;published:SiteContent;revision:number;draftUpdatedAt:number;publishedAt:number};

const pathname='ubex/site-content.json';
function storageToken(){
  const token=process.env.BLOB_READ_WRITE_TOKEN;
  if(!token) throw new Error('Website storage is not connected.');
  return token;
}
export async function getContentRow():Promise<ContentRow|null>{
  const blob=await get(pathname,{access:'private',token:storageToken(),useCache:false});
  if(!blob) return null;
  const parsed=JSON.parse(await new Response(blob.stream).text()) as ContentRow;
  return {draft:contentSchema.parse(parsed.draft),published:contentSchema.parse(parsed.published),revision:parsed.revision,draftUpdatedAt:parsed.draftUpdatedAt,publishedAt:parsed.publishedAt};
}
export async function getPublishedContent():Promise<SiteContent>{
  try{return (await getContentRow())?.published ?? defaults;}
  catch(error){
    console.error('Website content could not load',error);
    return defaults;
  }
}
export async function saveDraft(content:SiteContent,expectedRevision:number):Promise<number|null>{
  const row=await getContentRow();
  if((row?.revision??0)!==expectedRevision) return null;
  const now=Date.now();
  const next:ContentRow={draft:content,published:row?.published??defaults,revision:expectedRevision+1,draftUpdatedAt:now,publishedAt:row?.publishedAt??now};
  await put(pathname,JSON.stringify(next),{access:'private',token:storageToken(),allowOverwrite:true,contentType:'application/json'});
  return next.revision;
}
export async function publishDraft(expectedRevision:number):Promise<number|null>{
  const row=await getContentRow();
  if(!row||row.revision!==expectedRevision) return null;
  const next:ContentRow={...row,published:row.draft,revision:expectedRevision+1,publishedAt:Date.now()};
  await put(pathname,JSON.stringify(next),{access:'private',token:storageToken(),allowOverwrite:true,contentType:'application/json'});
  return next.revision;
}
