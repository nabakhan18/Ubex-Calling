import type { SiteContent } from './content';
import { siteTemplate } from './site-template';

const escapeHtml = (text: string) => text.replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]!));

export function renderSite(content: SiteContent) {
  const values: Record<string,string> = {};
  for(const [key,value] of Object.entries(content)) {
    if(typeof value === 'string') values[key] = escapeHtml(value);
    else value.forEach((pair,index) => {
      values[`${key}${index}Title`] = escapeHtml(pair[0]);
      values[`${key}${index}Description`] = escapeHtml(pair[1]);
    });
  }
  return siteTemplate.replace(/\{\{(\w+)\}\}/g, (_,key: string) => values[key] ?? '');
}
