import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { get, put } from '@vercel/blob';
import { cookies } from 'next/headers';

const COOKIE='ubex_admin';
const WEEK=7*24*60*60;
const AUTH_PATH='ubex/admin-auth.json';
const INITIAL_VERSION='initial';
const DEFAULT_ADMIN_EMAIL='ubex.service@gmail.com';
type StoredAuth={hash:string;version:string;email?:string;changedAt?:number};

function initialEmail(){return (process.env.ADMIN_EMAIL||DEFAULT_ADMIN_EMAIL).trim().toLowerCase();}
export async function adminEmail(){return (await authRecord()).email??initialEmail();}
function secret(){
  const value=process.env.ADMIN_SESSION_SECRET;
  if(!value||value.length<32) throw new Error('Admin login is not configured.');
  return value;
}
function storageToken(){
  const token=process.env.BLOB_READ_WRITE_TOKEN;
  if(!token) throw new Error('Admin storage is not connected.');
  return token;
}
function signature(payload:string){return createHmac('sha256',secret()).update(payload).digest('hex');}
function matches(left:string,right:string){
  const a=Buffer.from(left);const b=Buffer.from(right);
  return a.length===b.length && timingSafeEqual(a,b);
}
async function authRecord():Promise<StoredAuth>{
  const blob=await get(AUTH_PATH,{access:'private',token:storageToken(),useCache:false});
  if(blob){
    const parsed=JSON.parse(await new Response(blob.stream).text()) as StoredAuth;
    if(!parsed||typeof parsed.hash!=='string'||!/^([^:]+):[a-f0-9]{64}$/.test(parsed.hash)||
      typeof parsed.version!=='string'||!/^[a-f0-9]{32}$/.test(parsed.version)||
      (parsed.email!==undefined&&(typeof parsed.email!=='string'||!validEmail(parsed.email)))) throw new Error('Admin credentials are invalid.');
    return parsed;
  }
  const hash=process.env.ADMIN_PASSWORD_HASH;
  if(!hash) throw new Error('Admin login is not configured.');
  return {hash,version:INITIAL_VERSION};
}
function validEmail(value:string){return value.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);}
function passwordMatches(password:string,configured:string){
  const [salt,hash]=configured.split(':');
  if(!salt||!hash||password.length>256) return false;
  return matches(scryptSync(password,salt,32).toString('hex'),hash);
}
export async function isAdmin(){
  try{
    const cookie=(await cookies()).get(COOKIE)?.value;
    if(!cookie) return false;
    const [expiry,version,mac]=cookie.split('.');
    if(!expiry||!version||!mac||!/^[0-9]+$/.test(expiry)||Number(expiry)<Date.now()) return false;
    if(version!==(await authRecord()).version) return false;
    return matches(mac,signature(`${expiry}.${version}`));
  }catch{return false;}
}
export async function verifyPassword(password:string){
  return passwordMatches(password,(await authRecord()).hash);
}
export async function verifyLogin(email:string,password:string){
  const record=await authRecord();
  return passwordMatches(password,record.hash)&&email.trim().toLowerCase()===(record.email??initialEmail());
}
export async function changePassword(currentPassword:string,newPassword:string){
  const record=await authRecord();
  if(!passwordMatches(currentPassword,record.hash)) return false;
  if(newPassword.length<12||newPassword.length>128||newPassword===currentPassword) throw new Error('Choose a different password with at least 12 characters.');
  const salt=randomBytes(16).toString('hex');
  const next:StoredAuth={...record,hash:`${salt}:${scryptSync(newPassword,salt,32).toString('hex')}`,version:randomBytes(16).toString('hex'),changedAt:Date.now()};
  await put(AUTH_PATH,JSON.stringify(next),{access:'private',token:storageToken(),allowOverwrite:true,contentType:'application/json'});
  await startSession(next.version);
  return true;
}
export async function changeEmail(currentPassword:string,newEmail:string):Promise<string|false>{
  const record=await authRecord();
  if(!passwordMatches(currentPassword,record.hash)) return false;
  const normalized=newEmail.trim().toLowerCase();
  if(!validEmail(normalized)||normalized===(record.email??initialEmail())) throw new Error('Enter a different valid email address.');
  const next:StoredAuth={...record,email:normalized,version:randomBytes(16).toString('hex'),changedAt:Date.now()};
  await put(AUTH_PATH,JSON.stringify(next),{access:'private',token:storageToken(),allowOverwrite:true,contentType:'application/json'});
  await startSession(next.version);
  return normalized;
}
export async function startSession(version?:string){
  const activeVersion=version??(await authRecord()).version;
  const expiry=String(Date.now()+WEEK*1000);
  const payload=`${expiry}.${activeVersion}`;
  (await cookies()).set(COOKIE,`${payload}.${signature(payload)}`,{httpOnly:true,secure:true,sameSite:'lax',path:'/',maxAge:WEEK});
}
export async function endSession(){(await cookies()).delete(COOKIE);}
