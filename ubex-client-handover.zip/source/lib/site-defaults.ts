export const defaultContent = {
  "heroEyebrow": "A calling partner for service businesses",
  "heroTitle": "Your voice.",
  "heroAccent": "Their trust.",
  "heroDescription": "Real people answering, scheduling, following up, and keeping your customers connected. Trained to sound like your team, because every call matters.",
  "servicesTitle": "The whole conversation,",
  "servicesTitleSecond": "handled.",
  "servicesLead": "From the first hello to the follow-up after the job, UBEX helps you stay responsive without pulling your team away from the work.",
  "industriesTitle": "Your industry has its own",
  "industriesTitleSecond": "way of speaking.",
  "industriesLead": "We learn the vocabulary, urgency, and workflows behind your calls, so every customer gets the right response.",
  "processTitle": "From first call",
  "processTitleSecond": "to full flow.",
  "processLead": "We set up a calling program around your business, then keep refining it with you.",
  "aboutTitle": "A real team in",
  "aboutTitleSecond": "your corner.",
  "aboutLead": "UBEX answers, makes, and manages phone calls for growing service businesses. We work as an extension of your team, trained on your scripts and tone so callers feel understood.",
  "aboutPoint1": "People trained around your industry",
  "aboutPoint2": "Flexible coverage as call volume changes",
  "aboutPoint3": "Clear call summaries and performance reporting",
  "contactTitle": "Let's make every",
  "contactTitleSecond": "conversation count.",
  "contactLead": "Tell us about your business and call volume. We'll put together a calling plan that fits the way you work.",
  "contactEmail": "ubex.service@gmail.com",
  "services": [
    [
      "Inbound call handling",
      "Answer new inquiries, urgent calls, and everyday questions promptly and professionally."
    ],
    [
      "Outbound sales & leads",
      "Reach prospects, qualify interest, and book conversations for your sales team."
    ],
    [
      "Appointment scheduling",
      "Bookings, confirmations, and reminders that keep your calendar accurate."
    ],
    [
      "Customer support",
      "Helpful answers and clear handoffs when your team needs to step in."
    ],
    [
      "Follow-up & feedback",
      "Post-service check-ins, delivery confirmations, and customer feedback calls."
    ],
    [
      "Dispatch coordination",
      "Connect customers and field teams when jobs, schedules, or plans change."
    ]
  ],
  "industries": [
    [
      "Logistics & transportation",
      "Dispatch, driver coordination, delivery status, and ETA updates."
    ],
    [
      "Plumbing & home services",
      "Emergency requests, bookings, technician scheduling, and estimates."
    ],
    [
      "Real estate",
      "Lead qualification, viewings, and buyer or seller follow-up."
    ],
    [
      "Insurance",
      "Policy inquiries, claims follow-up, and renewal reminders."
    ],
    [
      "E-commerce & retail",
      "Order confirmations, delivery updates, and support overflow."
    ],
    [
      "Healthcare & clinics",
      "Appointment booking, reminders, and patient intake support."
    ]
  ],
  "steps": [
    [
      "Discovery",
      "We learn your services, customers, calling goals, and busy hours."
    ],
    [
      "Scripts & training",
      "Agents learn your tone, policies, and the details behind your work."
    ],
    [
      "Systems setup",
      "We connect with your phone, calendar, CRM, and dispatch workflow."
    ],
    [
      "Launch",
      "Your trained team starts handling real customer conversations."
    ],
    [
      "Improve",
      "We review outcomes and feedback to keep the program sharp."
    ]
  ]
} as const;
